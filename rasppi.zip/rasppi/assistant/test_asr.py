import os
import wave
import json
from vosk import Model, KaldiRecognizer

# Paths
MODEL_PATH = os.path.join("..", "models", "asr", "hindi-model")
AUDIO_PATH = os.path.join(os.path.dirname(__file__), "sample_hi.wav")  # Place your sample Hindi .wav here

# Open audio file
wf = wave.open(AUDIO_PATH, "rb")

# Load Vosk model
model = Model(MODEL_PATH)
rec = KaldiRecognizer(model, wf.getframerate())

# Recognize
while True:
    data = wf.readframes(4000)
    if len(data) == 0:
        break
    if rec.AcceptWaveform(data):
        print(json.loads(rec.Result()))
print(json.loads(rec.FinalResult()))