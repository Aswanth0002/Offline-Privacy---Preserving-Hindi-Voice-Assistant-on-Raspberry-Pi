from asr import listen_hindi
from tts import speak_hindi
from llm import ask_llm
from intent import check_intent, execute_intent

print("=== Hindi Voice Assistant Started ===")

while True:
    try:
        # --- Listen from Mic ---
        text = listen_hindi()
        if not text:
            continue

        print("You:", text)

        # --- Exit command ---
        if "बंद" in text or "exit" in text or "stop" in text:
            speak_hindi("ठीक है, असिस्टेंट बंद कर रहा हूँ।")
            break

        # --- Intent detection ---
        intent = check_intent(text)

        if intent == "llm":
            reply = ask_llm(text)
        else:
            reply = execute_intent(intent)

        print("Assistant:", reply)

        # --- Speak reply ---
        speak_hindi(reply)

    except KeyboardInterrupt:
        print("\nStopped manually")
        break

    except Exception as e:
        print("Error:", e)
        speak_hindi("माफ कीजिए, कुछ समस्या हो गई है।")