from datetime import datetime

def handle_intent(text):
    lower = text.lower()
    if "नमस्ते" in lower or "हाय" in lower:
        return "नमस्ते! मैं आपकी क्या मदद कर सकता हूँ?"
    elif "समय" in lower:
        return f"अभी समय है {datetime.now().strftime('%H:%M')}"
    elif "तारीख" in lower:
        return f"आज की तारीख है {datetime.now().strftime('%d %B %Y')}"
    elif "बंद" in lower or "stop" in lower or "exit" in lower:
        return "ठीक है, बंद कर रहा हूँ।"
    else:
        return f"आपने कहा: {text}"