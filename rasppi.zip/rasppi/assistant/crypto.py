from cryptography.fernet import Fernet

with open("key.key", "rb") as f:
    key = f.read()

fernet = Fernet(key)

def encrypt(message):
    return fernet.encrypt(message.encode())

def decrypt(enc_message):
    return fernet.decrypt(enc_message).decode()