from cryptography.fernet import Fernet

# Generate a key
key = Fernet.generate_key()

# Save it to key.key
with open("key.key", "wb") as f:
    f.write(key)

print("✅ key.key file generated successfully!")