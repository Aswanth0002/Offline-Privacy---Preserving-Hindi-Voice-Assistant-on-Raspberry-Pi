import requests

def ask_llm(prompt):
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "llama3",
                "prompt": f"तुम एक हिंदी वॉइस असिस्टेंट हो। हिंदी में उत्तर दो।\nUser: {prompt}",
                "stream": False,
            },
        )
        return response.json()["response"].strip()
    except:
        return "माफ कीजिए, अभी उत्तर देने में समस्या है।"