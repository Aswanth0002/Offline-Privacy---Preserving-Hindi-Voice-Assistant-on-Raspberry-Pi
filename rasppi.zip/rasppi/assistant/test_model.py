from vosk import Model
import os

# Absolute path to your Vosk Hindi model
MODEL_PATH = r"C:\Users\V Samuel\Downloads\VoiceAI\models\asr\Hindi-model"

if not os.path.exists(MODEL_PATH):
    raise Exception("ASR model folder not found at " + MODEL_PATH)

model = Model(MODEL_PATH)
print("✅ Model loaded successfully!")