# ================================================================
# OFFLINE HINDI VOICE ASSISTANT (FINAL SUBMISSION VERSION)
# Runs fully offline • Auto mic detect • Speaker fixed • Fast reply
# No echo loop • Works on Laptop → Copy same to Raspberry Pi
# ================================================================

import os
import queue
import json
import datetime
import sounddevice as sd
import vosk
import pyttsx3

# ---------------------- FORCE SYSTEM AUDIO -----------------------
# Uses default Windows speaker/headphone automatically
sd.default.device = None

# ---------------------- PATH CONFIG ------------------------------
ASR_MODEL_PATH = r"models\asr\hindi-model"

# ---------------------- CHECK ASR MODEL --------------------------
if not os.path.exists(ASR_MODEL_PATH):
    raise Exception("ASR model not found at " + ASR_MODEL_PATH)

# ---------------------- LOAD VOSK ASR ----------------------------
asr_model = vosk.Model(ASR_MODEL_PATH)
recognizer = vosk.KaldiRecognizer(asr_model, 16000)
print("✅ ASR loaded successfully")

# ---------------------- INIT TEXT TO SPEECH ----------------------
engine = pyttsx3.init()

# Set Hindi voice if available
voices = engine.getProperty('voices')
for v in voices:
    if "hindi" in v.name.lower() or "hi" in v.id.lower():
        engine.setProperty('voice', v.id)
        break

engine.setProperty('rate', 165)     # Speech speed
engine.setProperty('volume', 1.0)   # Max volume

# ---------------------- SPEAK FUNCTION ---------------------------
def speak(text):
    print("Assistant:", text)
    engine.say(text)
    engine.runAndWait()

# ---------------------- AUDIO QUEUE ------------------------------
audio_queue = queue.Queue()

# ---------------------- AUDIO CALLBACK ---------------------------
def audio_callback(indata, frames, time, status):
    if status:
        print(status)
    audio_queue.put(bytes(indata))

# ---------------------- AUTO MIC DETECT --------------------------
def find_mic():
    devices = sd.query_devices()
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0 and "mic" in d['name'].lower():
            return i
    return sd.default.device[0]

mic_index = find_mic()
print(f"🎤 Using microphone index: {mic_index}")

# ---------------------- COMMAND LOGIC ----------------------------
def process_command(text):

    text = text.strip()

    # -------- GREETING --------
    if "नमस्ते" in text or "हेलो" in text:
        return "नमस्ते, मैं आपकी सहायता के लिए तैयार हूँ।"

    # -------- TIME --------
    elif "समय" in text:
        now = datetime.datetime.now().strftime("%H:%M")
        return f"अभी समय {now} है।"

    # -------- DATE --------
    elif "तारीख" in text or "डेट" in text:
        today = datetime.datetime.now().strftime("%d %B %Y")
        return f"आज की तारीख {today} है।"

    # -------- DAY --------
    elif "दिन" in text:
        day = datetime.datetime.now().strftime("%A")
        return f"आज {day} है।"

    # -------- YOUR NAME --------
    elif "तुम कौन" in text or "नाम" in text:
        return "मैं आपका ऑफलाइन हिंदी वॉइस असिस्टेंट हूँ।"

    # -------- WEATHER (OFFLINE DEMO) --------
    elif "मौसम" in text:
        return "मैं ऑफलाइन हूँ, लेकिन आज मौसम सामान्य लग रहा है।"

    # -------- THANK YOU --------
    elif "धन्यवाद" in text:
        return "आपका स्वागत है।"

    # -------- STOP / EXIT --------
    elif "बंद" in text or "रुको" in text:
        speak("ठीक है, मैं बंद हो रहा हूँ।")
        exit()

    # -------- UNKNOWN --------
    else:
        return "मैं समझ नहीं पाया। कृपया फिर से कहें।"

# ---------------------- MAIN LOOP -------------------------------
def main():

    speak("नमस्ते, मैं आपका हिंदी वॉइस असिस्टेंट हूँ। बोलिए।")

    # Start microphone stream
    with sd.RawInputStream(
        samplerate=16000,
        blocksize=8000,
        dtype='int16',
        channels=1,
        callback=audio_callback,
        device=mic_index
    ):

        while True:
            data = audio_queue.get()

            if recognizer.AcceptWaveform(data):
                result = json.loads(recognizer.Result())
                text = result.get("text", "").strip()

                if text:
                    print("You:", text)
                    response = process_command(text)
                    speak(response)

# ---------------------- RUN PROGRAM ------------------------------
if __name__ == "__main__":
    main()