# ---------------- TEXT TO SPEECH (OFFLINE) ----------------
import pyttsx3

engine = pyttsx3.init()

# Try to select Hindi voice automatically
voices = engine.getProperty('voices')
selected = False
for v in voices:
    if "hindi" in v.name.lower() or "india" in v.name.lower():
        engine.setProperty('voice', v.id)
        selected = True
        break

# If Hindi voice not found, fallback to default voice
if not selected:
    engine.setProperty('voice', voices[0].id)

engine.setProperty('rate', 170)   # Speed (150–190 good range)
engine.setProperty('volume', 1.0) # Max volume


def speak(text):
    print("Assistant:", text)
    engine.say(text)
    engine.runAndWait()
# ---------------------------------------------------------