from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

# Model name
model_name = "google/flan-t5-small"

# Local path to save model
local_path = r"C:\Users\V Samuel\Downloads\VoiceAI\models\llm-hindi"

# Load model & tokenizer
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSeq2SeqLM.from_pretrained(model_name)

# Save locally
tokenizer.save_pretrained(local_path)
model.save_pretrained(local_path)

print("✅ LLM model saved locally at:", local_path)
